package com.example.BeTheFutureBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeTheFutureBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
