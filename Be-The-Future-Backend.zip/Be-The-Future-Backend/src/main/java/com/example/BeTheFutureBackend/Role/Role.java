package com.example.BeTheFutureBackend.Role;


public enum Role {

    ROLE_USER,
    ROLE_ADMIN,
    ROLE_EMPLOYEE,
    ROLE_CUSTOMER,
    ROLE_MANAGER
}
