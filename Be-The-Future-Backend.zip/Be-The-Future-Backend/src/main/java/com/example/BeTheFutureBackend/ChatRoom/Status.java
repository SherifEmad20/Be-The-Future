package com.example.BeTheFutureBackend.ChatRoom;

public enum Status {
    JOIN,
    MESSAGE,
    LEAVE
}
